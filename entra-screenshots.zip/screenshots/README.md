# Screenshots

Entra admin center screenshots used in the main [README](../README.md).

| File | What it shows |
|---|---|
| `it-support-members.png` | IT-Support group, Direct members: Alex Chen, John Smith, Madison Parks, Priya Patel |
| `sales-team-members.png` | Sales-Team group, Direct members: Mike Torres, Sarah Lee |
